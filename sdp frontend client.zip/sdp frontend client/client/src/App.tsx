import { Outlet, Link } from "react-router-dom";

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      {/* Navbar */}
      <nav className="flex justify-between items-center px-8 py-4 bg-gray-800 shadow-md">
        <h1 className="text-2xl font-bold text-indigo-400">🎮 GameClub</h1>
        <div className="space-x-6">
          <Link to="/" className="hover:text-indigo-300 transition">Home</Link>
          <Link to="/login" className="hover:text-indigo-300 transition">Login</Link>
          <Link to="/signup" className="hover:text-indigo-300 transition">Sign Up</Link>
        </div>
      </nav>

      {/* Page content */}
      <main className="p-8">
        <Outlet />
      </main>
    </div>
  );
};

export default App;
