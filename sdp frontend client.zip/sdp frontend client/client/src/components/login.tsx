const Login: React.FC = () => {
  return (
    <div className="flex items-center justify-center min-h-[70vh]">
      <div className="bg-gray-800 shadow-xl rounded-3xl p-10 w-full max-w-md text-gray-100">
        <h2 className="text-3xl font-bold text-indigo-400 mb-6 text-center">
          Login to GameClub
        </h2>

        <form className="flex flex-col gap-5">
          <input
            type="email"
            placeholder="Email"
            className="p-3 rounded-xl bg-gray-700 border border-gray-600 focus:outline-none focus:ring-2 focus:ring-indigo-400"
          />
          <input
            type="password"
            placeholder="Password"
            className="p-3 rounded-xl bg-gray-700 border border-gray-600 focus:outline-none focus:ring-2 focus:ring-indigo-400"
          />
          <button className="bg-indigo-500 hover:bg-indigo-600 text-white py-3 rounded-xl font-semibold transition">
            Login
          </button>
        </form>

        <p className="text-center text-gray-400 mt-4">
          Don’t have an account?{" "}
          <a href="/signup" className="text-green-400 hover:underline">
            Sign Up
          </a>
        </p>
      </div>
    </div>
  );
};

export default Login;
