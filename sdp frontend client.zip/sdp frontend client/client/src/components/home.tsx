const Home: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh]">
      <div className="bg-gray-800 text-gray-100 p-12 rounded-3xl shadow-2xl max-w-2xl text-center">
        <h1 className="text-5xl font-extrabold text-indigo-400 mb-6">
          Welcome to GameClub
        </h1>
        <p className="text-lg text-gray-300 mb-8">
          Buy your favorite games and manage access effortlessly.  
          Customers can browse and purchase games, while admins control access.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a
            href="/login"
            className="bg-indigo-500 hover:bg-indigo-600 transition text-white px-6 py-3 rounded-xl font-semibold"
          >
            Login
          </a>
          <a
            href="/signup"
            className="bg-green-500 hover:bg-green-600 transition text-white px-6 py-3 rounded-xl font-semibold"
          >
            Sign Up
          </a>
        </div>
      </div>
    </div>
  );
};

export default Home;
