function Customerdashboard() {
    return (
        <div>
            <h1>Customer DashBoard</h1>
        </div>
    )
}

export default Customerdashboard;